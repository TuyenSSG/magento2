# Installation

Copy extension to /app/code

Then run:

```bash
php bin/magento module:status
php bin/magento module:enable BitMike_YoutubeWidget
php bin/magento setup:upgrade
```