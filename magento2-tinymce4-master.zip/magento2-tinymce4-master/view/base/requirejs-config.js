var config = {
	"shim": {
		"PavelLeonidov_TinyMce4/lib/tinymce4/tinymce.full.min": { "exports": "tinymce" }
	}
};
