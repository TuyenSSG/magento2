<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Block\Adminhtml\Attribute\Edit\Tab;

use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Catalog\Block\Adminhtml\Form;
use Magento\Catalog\Model\ResourceModel\Eav\Attribute;
use Magento\Eav\Model\Entity\Attribute\AbstractAttribute;
use Magento\Framework\Data\FormFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Phrase;
use Magento\Framework\Registry;
use Mageplaza\StockStatus\Block\Adminhtml\Attribute\Edit\Tab\Renderer\Table;
use Mageplaza\StockStatus\Helper\Data;

/**
 * Class DynamicGroup
 *
 * @package Mageplaza\StockStatus\Block\Adminhtml\Attribute\Edit\Tab
 */
class DynamicGroup extends Form implements TabInterface
{
    /**
     * @var Data
     */
    protected $_helperData;

    /**
     * DynamicGroup constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param Data $helperData
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        Data $helperData,
        array $data = []
    ) {
        $this->_helperData = $helperData;

        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * @return Form
     * @throws LocalizedException
     */
    protected function _prepareForm()
    {
        if (!$this->isCustomAttribute()) {
            return parent::_prepareForm();
        }

        /** @var Attribute $attributeObject */
        $attributeObject = $this->getAttributeObject();
        if ($attributeObject->getData('additional_data')) {
            $additionalData = $this->_helperData->unserialize($attributeObject->getData('additional_data'));
            if (is_array($additionalData)) {
                $attributeObject->setData('group_items', $additionalData);
            }
        }

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post']]
        );

        $fieldset = $form->addFieldset('dynamic_group_fieldset', [
            'legend' => __('Dynamic Quantity Groups Properties'),
            'class'  => 'fieldset-wide'
        ]);

        $fieldset->addField('group_items', Table::class, [
            'name' => 'group_items',
            'note' => __('Set a quantity range to apply a specific stock status automatically.')
        ]);

        $this->setForm($form);
        $form->setValues($attributeObject->getData());

        return parent::_prepareForm();
    }

    /**
     * @return bool
     */
    public function isCustomAttribute()
    {
        return $this->_helperData->isEnabled()
            && $this->getAttributeObject()->getAttributeCode() === 'mp_dynamic_groups';
    }

    /**
     * @return AbstractAttribute|mixed
     */
    protected function getAttributeObject()
    {
        return $this->_coreRegistry->registry('entity_attribute');
    }

    /**
     * @return Phrase
     */
    public function getTabLabel()
    {
        return __('Dynamic Quantity Groups Properties');
    }

    /**
     * @return Phrase
     */
    public function getTabTitle()
    {
        return __('Dynamic Quantity Groups Properties');
    }

    /**
     * @return bool
     */
    public function canShowTab()
    {
        return $this->isCustomAttribute();
    }

    /**
     * @return bool
     */
    public function isHidden()
    {
        return false;
    }
}
