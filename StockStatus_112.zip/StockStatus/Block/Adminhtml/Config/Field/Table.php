<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Block\Adminhtml\Config\Field;

use Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Element\BlockInterface;

/**
 * Class Table
 *
 * @package Mageplaza\StockStatus\Block\Adminhtml\Config\Field
 */
class Table extends AbstractFieldArray
{
    /**
     * @var DynamicGroup
     */
    protected $_groupRenderer;

    /**
     * @var StockStatus
     */
    protected $_statusRenderer;

    /**
     * Retrieve group name column renderer
     *
     * @return BlockInterface|DynamicGroup
     * @throws LocalizedException
     */
    protected function _getGroupNameRenderer()
    {
        if (!$this->_groupRenderer) {
            $this->_groupRenderer = $this->getLayout()->createBlock(DynamicGroup::class, '', [
                'data' => ['is_render_to_js_template' => true]
            ]);
            $this->_groupRenderer->setClass('group_name_select');
        }

        return $this->_groupRenderer;
    }

    /**
     * Retrieve stock status column renderer
     *
     * @return BlockInterface|DynamicGroup
     * @throws LocalizedException
     */
    protected function _getStockStatusRenderer()
    {
        if (!$this->_statusRenderer) {
            $this->_statusRenderer = $this->getLayout()->createBlock(
                StockStatus::class,
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_statusRenderer->setClass('stock_status_select');
        }

        return $this->_statusRenderer;
    }

    /**
     * @throws LocalizedException
     */
    protected function _prepareToRender()
    {
        $this->addColumn('group_name', [
            'label'    => __('Group Name'),
            'size'     => '200px',
            'renderer' => $this->_getGroupNameRenderer()
        ]);

        $this->addColumn('stock_status', [
            'label'    => __('Stock Status'),
            'size'     => '200px',
            'renderer' => $this->_getStockStatusRenderer()
        ]);

        $this->addColumn('qty_from', [
            'label'    => __('Quantity From'),
            'class'    => 'validate-number',
            'renderer' => false
        ]);

        $this->addColumn('qty_to', [
            'label'    => __('Quantity To'),
            'class'    => 'validate-number',
            'renderer' => false
        ]);

        $this->_addAfter       = false;
        $this->_addButtonLabel = __('Add');
    }

    /**
     * Prepare existing row data object
     *
     * @param DataObject $row
     *
     * @throws LocalizedException
     */
    protected function _prepareArrayRow(DataObject $row)
    {
        $groupNameRenderer   = $this->_getGroupNameRenderer();
        $stockStatusRenderer = $this->_getStockStatusRenderer();

        $row->setData('option_extra_attrs', [
            'option_' . $groupNameRenderer->calcOptionHash($row->getData('group_name'))     => 'selected="selected"',
            'option_' . $stockStatusRenderer->calcOptionHash($row->getData('stock_status')) => 'selected="selected"'
        ]);
    }
}
