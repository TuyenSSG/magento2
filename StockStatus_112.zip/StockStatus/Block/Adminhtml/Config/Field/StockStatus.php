<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Block\Adminhtml\Config\Field;

use Magento\Catalog\Model\Product;
use Magento\Eav\Model\Config as EavConfig;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Element\Context;
use Magento\Framework\View\Element\Html\Select;

/**
 * Class StockStatus
 *
 * @package Mageplaza\StockStatus\Block\Adminhtml\Config\Field
 */
class StockStatus extends Select
{
    /**
     * DStock status cache
     *
     * @var array
     */
    private $_stockStatus;

    /**
     * @var EavConfig
     */
    protected $_eavConfig;

    /**
     * DynamicGroup constructor.
     *
     * @param Context $context
     * @param EavConfig $eavConfig
     * @param array $data
     */
    public function __construct(
        Context $context,
        EavConfig $eavConfig,
        array $data = []
    ) {
        $this->_eavConfig = $eavConfig;

        parent::__construct($context, $data);
    }

    /**
     * @param null $statusId
     *
     * @return array|mixed|null
     * @throws LocalizedException
     */
    protected function getStockStatus($statusId = null)
    {
        if ($this->_stockStatus === null) {
            $attribute = $this->_eavConfig->getAttribute(Product::ENTITY, 'mp_stock_status');
            foreach ($attribute->getSource()->getAllOptions() as $option) {
                $this->_stockStatus[$option['value']] = $option['label'];
            }
        }

        if ($statusId !== null) {
            return isset($this->_stockStatus[$statusId]) ? $this->_stockStatus[$statusId] : null;
        }

        return $this->_stockStatus;
    }

    /**
     * @param string $value
     *
     * @return $this
     */
    public function setInputName($value)
    {
        return $this->setName($value);
    }

    /**
     * @return string
     * @throws LocalizedException
     */
    public function _toHtml()
    {
        if (!$this->getOptions()) {
            foreach ($this->getStockStatus() as $groupId => $groupLabel) {
                $this->addOption($groupId, addslashes($groupLabel));
            }
        }

        return parent::_toHtml();
    }
}
