<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Block\Adminhtml\Config\Field;

use Magento\Catalog\Model\Product;
use Magento\Eav\Model\Config as EavConfig;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Element\Context;
use Magento\Framework\View\Element\Html\Select;

/**
 * Class DynamicGroup
 *
 * @package Mageplaza\StockStatus\Block\Adminhtml\Config\Field
 */
class DynamicGroup extends Select
{
    /**
     * Dynamic groups cache
     *
     * @var array
     */
    private $_dynamicGroups;

    /**
     * @var EavConfig
     */
    protected $_eavConfig;

    /**
     * DynamicGroup constructor.
     *
     * @param Context $context
     * @param EavConfig $eavConfig
     * @param array $data
     */
    public function __construct(
        Context $context,
        EavConfig $eavConfig,
        array $data = []
    ) {
        $this->_eavConfig = $eavConfig;

        parent::__construct($context, $data);
    }

    /**
     * @param null $groupId
     *
     * @return array|mixed|null
     * @throws LocalizedException
     */
    protected function getDynamicGroup($groupId = null)
    {
        if ($this->_dynamicGroups === null) {
            $attribute = $this->_eavConfig->getAttribute(Product::ENTITY, 'mp_dynamic_groups');
            foreach ($attribute->getSource()->getAllOptions() as $option) {
                $this->_dynamicGroups[$option['value']] = $option['label'];
            }
        }

        if ($groupId !== null) {
            return isset($this->_dynamicGroups[$groupId]) ? $this->_dynamicGroups[$groupId] : null;
        }

        return $this->_dynamicGroups;
    }

    /**
     * @param string $value
     *
     * @return $this
     */
    public function setInputName($value)
    {
        return $this->setName($value);
    }

    /**
     * @return string
     * @throws LocalizedException
     */
    public function _toHtml()
    {
        if (!$this->getOptions()) {
            foreach ($this->getDynamicGroup() as $groupId => $groupLabel) {
                $this->addOption($groupId, addslashes($groupLabel));
            }
        }

        return parent::_toHtml();
    }
}
