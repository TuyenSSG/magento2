<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Block\Product\View;

use Magento\Catalog\Block\Product\Context;
use Magento\Catalog\Block\Product\View\AbstractView;
use Magento\Framework\Stdlib\ArrayUtils;
use Mageplaza\StockStatus\Helper\Data;
use Mageplaza\StockStatus\Model\Config\Source\PageType;

/**
 * Class StockStatus
 *
 * @package Mageplaza\StockStatus\Block\Product\View
 */
class StockStatus extends AbstractView
{
    /**
     * @var Data
     */
    protected $_helperData;

    /**
     * StockStatus constructor.
     *
     * @param Context $context
     * @param ArrayUtils $arrayUtils
     * @param Data $helperData
     * @param array $data
     */
    public function __construct(
        Context $context,
        ArrayUtils $arrayUtils,
        Data $helperData,
        array $data = []
    ) {
        $this->_helperData = $helperData;

        parent::__construct($context, $arrayUtils, $data);
    }

    /**
     * @return bool
     */
    public function isDisplayStatus()
    {
        return $this->_helperData->isDisplayStatus($this->getProduct()->isAvailable(), PageType::PRODUCT_VIEW)
            && $this->getStatus();
    }

    /**
     * @return string
     */
    public function getStatus()
    {
        return $this->_helperData->getStatus($this->getProduct());
    }
}
