<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Block\Product\View\Type;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Block\Product\Context;
use Magento\Catalog\Block\Product\View\AbstractView;
use Magento\Catalog\Model\Product;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Stdlib\ArrayUtils;
use Mageplaza\StockStatus\Helper\Data;
use Mageplaza\StockStatus\Model\Config\Source\PageType;

/**
 * Class Configurable
 *
 * @package Mageplaza\StockStatus\Block\Product\View\Type
 */
class Configurable extends AbstractView
{
    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var Data
     */
    protected $_helperData;

    /**
     * Configurable constructor.
     *
     * @param Context $context
     * @param ArrayUtils $arrayUtils
     * @param ProductRepositoryInterface $productRepository
     * @param Data $helperData
     * @param array $data
     */
    public function __construct(
        Context $context,
        ArrayUtils $arrayUtils,
        ProductRepositoryInterface $productRepository,
        Data $helperData,
        array $data = []
    ) {
        $this->productRepository = $productRepository;
        $this->_helperData       = $helperData;

        parent::__construct($context, $arrayUtils, $data);
    }

    /**
     * @return array|string
     */
    public function getConfigurableChildren()
    {
        $product = $this->getProduct();
        if (!method_exists($product->getTypeInstance(), 'getConfigurableOptions')) {
            return [];
        }

        $result = [];

        $data = $product->getTypeInstance()->getConfigurableOptions($product);
        foreach ($data as $key => $datum) {
            foreach ($datum as $item) {
                $sku                = $item['sku'];
                $result[$sku][$key] = (int) $item['value_index'];

                try {
                    /** @var Product $prod */
                    $prod   = $this->productRepository->get($item['sku']);
                    $status = $this->_helperData->getStatus($prod);
                    if ($status) {
                        $result[$sku]['status'] = $status;
                    }
                } catch (NoSuchEntityException $e) {
                    $result[$sku]['message'] = __('Requested %1 product doesn\'t exist', $sku);
                    $this->_logger->critical($e->getMessage());
                }
            }
        }

        return $this->_helperData->getJsonEncode($result);
    }

    /**
     * @return array|string
     */
    public function getOptionMap()
    {
        $product = $this->getProduct();
        if (!method_exists($product->getTypeInstance(), 'getConfigurableOptions')) {
            return [];
        }

        $result = array_keys($product->getTypeInstance()->getConfigurableOptions($product));

        return $this->_helperData->getJsonEncode($result);
    }

    /**
     * @return string
     */
    public function getConfigurableStatus()
    {
        $stockQty = $this->_helperData->getStatus($this->getProduct());

        return $this->_helperData->getJsonEncode($stockQty);
    }

    /**
     * @return bool
     */
    public function isDisplayStatus()
    {
        return $this->_helperData->isDisplayStatus($this->getProduct()->isAvailable(), PageType::PRODUCT_VIEW)
            && $this->_helperData->isDisplayChildProduct()
            && $this->getConfigurableStatus();
    }
}
