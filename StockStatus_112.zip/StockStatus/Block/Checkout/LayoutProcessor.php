<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Block\Checkout;

use Magento\Checkout\Block\Checkout\LayoutProcessorInterface;
use Mageplaza\StockStatus\Helper\Data;

/**
 * Class LayoutProcessor
 *
 * @package Mageplaza\StockStatus\Block\Checkout
 */
class LayoutProcessor implements LayoutProcessorInterface
{
    /**
     * @var Data
     */
    protected $helperData;

    /**
     * LayoutProcessor constructor.
     *
     * @param Data $helperData
     */
    public function __construct(Data $helperData)
    {
        $this->helperData = $helperData;
    }

    /**
     * Process js Layout of block
     *
     * @param array $jsLayout
     *
     * @return array
     */
    public function process($jsLayout)
    {
        if (!$this->helperData->isEnabled()) {
            return $jsLayout;
        }

        $fields = &$jsLayout['components']['checkout']['children']['sidebar']['children']['summary']['children']
        ['cart_items']['children'];

        $orderData = [
            'component' => 'Mageplaza_StockStatus/js/view/summary/item/details/osc-stock',
        ];
        if ($this->helperData->isOscPage()) {
            $fields = &$jsLayout['components']['checkout']['children']['sidebar']['children']['summary']['children']
            ['cart_items']['children']['details']['children'];

            $orderData['template']    = 'Mageplaza_StockStatus/summary/item/details/osc-stock';
            $orderData['displayArea'] = 'after_item_details';
        }

        $fields['stock'] = $orderData;

        return $jsLayout;
    }
}
