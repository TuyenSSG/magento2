/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'underscore',
        'Magento_Checkout/js/view/summary/abstract-total',
        'Mageplaza_StockStatus/js/model/osc-stock'
    ], function (_, Component, stock) {
        'use strict';

        return Component.extend(
            {
                getValue: function (item) {
                    var product = _.findWhere(stock.config(), {item_id: item.item_id + ''}) || {};

                    if (!_.isEmpty(product) && product.hasOwnProperty('stock_status')) {
                        return product.stock_status;
                    }

                    return '';
                }
            }
        );
    }
);
