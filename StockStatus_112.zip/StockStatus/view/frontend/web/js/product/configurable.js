/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'jquery',
        'underscore'
    ], function ($, _) {
        "use strict";

        $.widget('mageplaza.stockstatus', {
                _create: function () {
                    var self = this,
                        container = $('#product-options-wrapper');

                    if (container.find('.swatch-opt').length) {
                        self.swatchAttribute();
                    } else {
                        self.dropdownAttribute();
                    }
                },

                /**
                 * reload stock status on changing swatch options
                 */
                swatchAttribute: function () {
                    var self = this,
                        container = $('#product-options-wrapper');

                    container.on(
                        'change',
                        '.swatch-input',
                        function () {
                            var status,
                                options = _.object(self.options.optionMap, []);

                            $(this).parents('.swatch-opt').find('.swatch-attribute[option-selected]').each(
                                function () {
                                    var attributeId = parseInt($(this).attr('attribute-id'), 10);

                                    options[attributeId] = parseInt($(this).attr('option-selected'), 10);
                                }
                            );

                            status = _.findWhere(self.options.configurable, options) || {};
                            if (status.status) {
                                $('.mp-stock-status .stock').html(status.status);
                            } else {
                                $('.mp-stock-status .stock').html(self.options.configurableStatus);
                            }
                        }
                    );
                },

                /**
                 * show countdown timer on changing dropdown options
                 */
                dropdownAttribute: function () {
                    var self = this,
                        container = $('#product-options-wrapper');

                    container.on(
                        'change',
                        '.super-attribute-select',
                        function () {
                            var status,
                                options = _.object(self.options.optionMap, []);

                            container.find('.super-attribute-select').each(
                                function () {
                                    var attributeId = this.config.id;

                                    options[attributeId] = parseInt(this.value, 10);
                                }
                            );

                            status = _.findWhere(self.options.configurable, options) || {};
                            if (status.status) {
                                $('.mp-stock-status').html(status.status);
                            } else {
                                $('.mp-stock-status').html(self.options.configurableStatus);
                            }
                        }
                    );
                }
            }
        );

        return $.mageplaza.stockstatus;
    }
);
