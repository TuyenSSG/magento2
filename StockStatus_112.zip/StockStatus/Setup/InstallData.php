<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Setup;

use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ResourceModel\Eav\Attribute as eavAttribute;
use Magento\Eav\Model\Config as EavConfig;
use Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Option\CollectionFactory;
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

/**
 * Class InstallData
 *
 * @package Mageplaza\StockStatus\Setup
 */
class InstallData implements InstallDataInterface
{
    /**
     * @var EavSetupFactory
     */
    protected $eavSetupFactory;

    /**
     * @var EavConfig
     */
    protected $eavConfig;

    /**
     * @var CollectionFactory
     */
    protected $attrCollectionFactory;

    /**
     * @var array
     */
    private $optionCollection = [];

    /**
     * @var array
     */
    protected $colorMap = [
        'Black'    => '#000000',
        'Blue'     => '#1857f7',
        'Brown'    => '#945454',
        'Gray'     => '#8f8f8f',
        'Green'    => '#53a828',
        'Lavender' => '#ce64d4',
        'Multi'    => '#ffffff',
        'Orange'   => '#eb6703',
        'Purple'   => '#ef3dff',
        'Red'      => '#ff0000',
        'White'    => '#ffffff',
        'Yellow'   => '#ffd500',
    ];

    /**
     * InstallData constructor.
     *
     * @param EavSetupFactory $eavSetupFactory
     * @param EavConfig $eavConfig
     * @param CollectionFactory $attrCollectionFactory
     */
    public function __construct(
        EavSetupFactory $eavSetupFactory,
        EavConfig $eavConfig,
        CollectionFactory $attrCollectionFactory
    ) {
        $this->eavSetupFactory       = $eavSetupFactory;
        $this->eavConfig             = $eavConfig;
        $this->attrCollectionFactory = $attrCollectionFactory;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     *
     * @throws LocalizedException
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        /** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        $eavSetup->addAttribute(Product::ENTITY, 'mp_stock_status', [
            'type'                    => 'varchar',
            'label'                   => __('Custom Stock Status'),
            'note'                    => 'Added by Mageplaza Custom Stock Status extension',
            'input'                   => 'select',
            'default'                 => '',
            'global'                  => ScopedAttributeInterface::SCOPE_GLOBAL,
            'group'                   => 'Product Details',
            'class'                   => '',
            'visible'                 => true,
            'visible_on_front'        => false,
            'required'                => false,
            'user_defined'            => true,
            'searchable'              => false,
            'filterable'              => false,
            'comparable'              => false,
            'used_in_product_listing' => false,
            'sort_order'              => 60,
            'apply_to'                => '',
        ])
            ->addAttribute(Product::ENTITY, 'mp_dynamic_groups', [
                'type'         => 'varchar',
                'label'        => __('Dynamic Quantity Groups Properties'),
                'note'         => 'Added by Mageplaza Custom Stock Status extension',
                'input'        => 'multiselect',
                'default'      => '',
                'global'       => ScopedAttributeInterface::SCOPE_GLOBAL,
                'backend'      => ArrayBackend::class,
                'group'        => 'Product Details',
                'class'        => '',
                'visible'      => true,
                'required'     => false,
                'user_defined' => true,
                'searchable'   => false,
                'filterable'   => false,
                'comparable'   => false,
                'sort_order'   => 60,
                'apply_to'     => ''
            ]);

        $attribute = $this->eavConfig->getAttribute(Product::ENTITY, 'mp_stock_status');
        if (!$attribute) {
            return;
        }
        $attributeData['option']            = $this->addExistingOptions($attribute);
        $attributeData['frontend_input']    = 'select';
        $attributeData['swatch_input_type'] = 'visual';
        $attributeData['optionvisual']      = $this->getOptionSwatch($attributeData);
        $attributeData['swatchvisual']      = $this->getOptionSwatchVisual($attributeData);

        $attribute->addData($attributeData);
        $attribute->save();
    }

    /**
     * @param array $attributeData
     *
     * @return array
     */
    protected function getOptionSwatch(array $attributeData)
    {
        $optionSwatch = ['order' => [], 'value' => [], 'delete' => []];
        $count        = 0;
        foreach ($attributeData['option'] as $optionKey => $optionValue) {
            $optionSwatch['delete'][$optionKey] = '';
            $optionSwatch['order'][$optionKey]  = (string) $count++;
            $optionSwatch['value'][$optionKey]  = [$optionValue, ''];
        }

        return $optionSwatch;
    }

    /**
     * @param array $attributeData
     *
     * @return array
     */
    private function getOptionSwatchVisual(array $attributeData)
    {
        $optionSwatch = ['value' => []];
        foreach ($attributeData['option'] as $optionKey => $optionValue) {
            if (strpos($optionValue, '#') === '0' && strlen($optionValue) === 7) {
                $optionSwatch['value'][$optionKey] = $optionValue;
            } else {
                if (isset($this->colorMap[$optionValue])) {
                    $optionSwatch['value'][$optionKey] = $this->colorMap[$optionValue];
                } else {
                    $optionSwatch['value'][$optionKey] = '';
                }
            }
        }

        return $optionSwatch;
    }

    /**
     * @param eavAttribute $attribute
     *
     * @return array
     */
    protected function addExistingOptions(eavAttribute $attribute)
    {
        $options     = [];
        $attributeId = $attribute->getId();
        if ($attributeId) {
            $this->loadOptionCollection($attributeId);
            foreach ($this->optionCollection[$attributeId] as $option) {
                $options[$option->getId()] = $option->getValue();
            }
        }

        return $options;
    }

    /**
     * @param $attributeId
     */
    protected function loadOptionCollection($attributeId)
    {
        if (empty($this->optionCollection[$attributeId])) {
            $this->optionCollection[$attributeId] = $this->attrCollectionFactory->create()
                ->setAttributeFilter($attributeId)
                ->setPositionOrder('asc', true)
                ->load();
        }
    }
}
