<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Plugin\Model;

use Magento\Catalog\Model\ResourceModel\Eav\Attribute;
use Mageplaza\StockStatus\Helper\Data;

/**
 * Class EavAttribute
 *
 * @package Mageplaza\StockStatus\Plugin\Model
 */
class EavAttribute
{
    /**
     * @var Data
     */
    protected $_helperData;

    /**
     * EavAttribute constructor.
     *
     * @param Data $helperData
     */
    public function __construct(Data $helperData)
    {
        $this->_helperData = $helperData;
    }

    /**
     * @param Attribute $attribute
     */
    public function beforeSave(Attribute $attribute)
    {
        if ($this->_helperData->isEnabled() && $attribute->getAttributeCode() === 'mp_dynamic_groups') {
            $additionalData = $attribute->getData('group_items');
            unset($additionalData['__empty']);

            $attribute->setData('additional_data', $this->_helperData->serialize($additionalData));
        }
    }
}
