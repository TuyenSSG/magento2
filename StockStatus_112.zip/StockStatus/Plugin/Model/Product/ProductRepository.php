<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Plugin\Model\Product;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Framework\Api\SearchResults;
use Magento\Framework\Exception\LocalizedException;
use Mageplaza\StockStatus\Helper\Data;
use Mageplaza\StockStatus\Model\Config\Source\StatusFormat;

/**
 * Class ProductRepository
 * @package Mageplaza\StockStatus\Plugin\Model\Product
 */
class ProductRepository
{
    /**
     * @var Data
     */
    protected $helperData;

    /**
     * ProductRepository constructor.
     *
     * @param Data $helperData
     */
    public function __construct(
        Data $helperData
    ) {
        $this->helperData = $helperData;
    }

    /**
     * @param ProductRepositoryInterface $subject
     * @param Product $result
     *
     * @return Product
     * @throws LocalizedException
     */

    public function afterGet(
        ProductRepositoryInterface $subject,
        $result
    ) {
        if (!$this->helperData->isEnabled()) {
            return $result;
        }

        $this->addStockStatus($result);

        return $result;
    }

    /**
     * @param Product $product
     *
     * @throws LocalizedException
     */
    public function addStockStatus($product)
    {
        $stockStatus         = $this->helperData->getStatus($product, false);
        $extensionAttributes = $product->getExtensionAttributes();

        if ($product->getTypeId() === Configurable::TYPE_CODE) {
            $extensionAttributes->setMpStockStatusIsApplyChild($this->helperData->isDisplayChildProduct());
        }

        $format = (int) $this->helperData->getStatusFormat();
        $status = [StatusFormat::LABEL_IMAGE, StatusFormat::IMAGE_LABEL];
        if (isset($stockStatus['image']) && in_array($format, array_merge($status, [StatusFormat::ONLY_IMAGE]), true)) {
            $extensionAttributes->setMpStockStatusImage($stockStatus['image']);
        }

        if (isset($stockStatus['label']) && in_array($format, array_merge($status, [StatusFormat::ONLY_LABEL]), true)) {
            $extensionAttributes->setMpStockStatusLabel($stockStatus['label']);
        }
    }

    /**
     * @param ProductRepositoryInterface $subject
     * @param SearchResults $searchCriteria
     *
     * @return SearchResults
     * @throws LocalizedException
     */
    public function afterGetList(
        ProductRepositoryInterface $subject,
        SearchResults $searchCriteria
    ) {
        if (!$this->helperData->isEnabled()) {
            return $searchCriteria;
        }

        /** @var Product $entity */
        foreach ($searchCriteria->getItems() as $entity) {
            $this->addStockStatus($entity);
        }

        return $searchCriteria;
    }
}
