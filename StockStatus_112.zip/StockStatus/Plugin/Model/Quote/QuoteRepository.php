<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Plugin\Model\Quote;

use Magento\Quote\Api\Data\CartInterface;
use Mageplaza\StockStatus\Helper\Data;
use Mageplaza\StockStatus\Model\Config\Source\PageType;
use Mageplaza\StockStatus\Model\Config\Source\StatusFormat;

/**
 * Class QuoteRepository
 * @package Mageplaza\StockStatus\Plugin\Model\Quote
 */
class QuoteRepository
{
    /**
     * @var Data
     */
    protected $helperData;

    /**
     * QuoteRepository constructor.
     *
     * @param Data $helperData
     */
    public function __construct(Data $helperData)
    {
        $this->helperData = $helperData;
    }

    /**
     * @param \Magento\Quote\Model\QuoteRepository $subject
     * @param CartInterface $quote
     *
     * @return CartInterface
     */
    public function afterGet(\Magento\Quote\Model\QuoteRepository $subject, $quote)
    {
        $this->addStockStatus($quote);

        return $quote;
    }

    /**
     * @param \Magento\Quote\Model\QuoteRepository $subject
     * @param CartInterface $quote
     *
     * @return CartInterface
     */
    public function afterGetForCustomer(\Magento\Quote\Model\QuoteRepository $subject, $quote)
    {
        $this->addStockStatus($quote);

        return $quote;
    }

    /**
     * @param CartInterface $quote
     */
    public function addStockStatus($quote)
    {
        $items = $quote->getItems();
        if ($items && $this->helperData->isEnabled()) {
            $status         = [StatusFormat::LABEL_IMAGE, StatusFormat::IMAGE_LABEL];
            $imageAvailable = array_merge($status, [StatusFormat::ONLY_IMAGE]);
            $textAvailable  = array_merge($status, [StatusFormat::ONLY_LABEL]);
            $format         = (int) $this->helperData->getStatusFormat();
            foreach ($items as $item) {
                if (!$item->getItemId()) {
                    continue;
                }

                $product   = $this->helperData->getProductData($item->getProduct());
                $isDisplay = $this->helperData->isDisplayStatus($product->isAvailable(), PageType::SHOPPING_CART);

                if ($isDisplay) {
                    $stockStatus         = $this->helperData->getStatus($product, false);
                    $extensionAttributes = $item->getExtensionAttributes();

                    if ($extensionAttributes && $stockStatus['image'] && in_array($format, $imageAvailable, true)) {
                        $extensionAttributes->setMpStockStatusImage($stockStatus['image']);
                    }

                    if ($extensionAttributes && $stockStatus['label'] && in_array($format, $textAvailable, true)) {
                        $extensionAttributes->setMpStockStatusLabel($stockStatus['label']);
                    }
                }
            }
        }
    }
}
