<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Plugin\Model\Quote;

use Closure;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\CartTotalRepositoryInterface;
use Magento\Quote\Api\Data\TotalsExtensionFactory;
use Magento\Quote\Api\Data\TotalsExtensionInterface;
use Magento\Quote\Api\Data\TotalsInterface;
use Magento\Quote\Model\Quote;
use Mageplaza\StockStatus\Helper\Data;

/**
 * Class CartTotalRepository
 *
 * @package Mageplaza\StockStatus\Plugin\Model\Quote
 */
class CartTotalRepository
{
    /**
     * @var TotalsExtensionFactory
     */
    protected $totalsExtension;

    /**
     * @var CartRepositoryInterface
     */
    protected $cartRepository;

    /**
     * @var Data
     */
    protected $helperData;

    /**
     * CartTotalRepository constructor.
     *
     * @param TotalsExtensionFactory $totalsExtension
     * @param CartRepositoryInterface $cartRepository
     * @param Data $helperData
     */
    public function __construct(
        TotalsExtensionFactory $totalsExtension,
        CartRepositoryInterface $cartRepository,
        Data $helperData
    ) {
        $this->totalsExtension = $totalsExtension;
        $this->cartRepository  = $cartRepository;
        $this->helperData      = $helperData;
    }

    /**
     * @param CartTotalRepositoryInterface $subject
     * @param Closure $proceed
     * @param $cartId
     *
     * @return TotalsInterface
     * @throws NoSuchEntityException
     */
    public function aroundGet(CartTotalRepositoryInterface $subject, Closure $proceed, $cartId)
    {
        /** @var TotalsInterface $quoteTotals */
        $quoteTotals = $proceed($cartId);

        /** @var Quote $quote */
        $quote = $this->cartRepository->getActive($cartId);

        $config = [];

        if ($this->helperData->isEnabled($quote->getStoreId())) {
            $items = $quoteTotals->getItems();
            foreach ($items as $item) {
                $quoteItem = $quote->getItemById($item->getItemId());
                $product   = $this->helperData->getProductData($quoteItem->getProduct());
                if ($this->helperData->checkProductType($product->isAvailable())) {
                    $config[] = [
                        'item_id'      => $item->getItemId(),
                        'stock_status' => $this->helperData->getStatus($product)
                    ];
                } else {
                    $config[] = [
                        'item_id' => $item->getItemId()
                    ];
                }
            }
        }

        /** @var TotalsExtensionInterface $totalsExtension */
        $totalsExtension = $quoteTotals->getExtensionAttributes() ?: $this->totalsExtension->create();
        $totalsExtension->setMpStockStatus(Data::jsonEncode($config));

        $quoteTotals->setExtensionAttributes($totalsExtension);

        return $quoteTotals;
    }
}
