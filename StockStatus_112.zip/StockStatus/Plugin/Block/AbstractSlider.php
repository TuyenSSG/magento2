<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Plugin\Block;

use Magento\Catalog\Model\Product;
use Mageplaza\Productslider\Block\AbstractSlider as Productslider;
use Mageplaza\StockStatus\Helper\Data;
use Mageplaza\StockStatus\Model\Config\Source\PageType;

/**
 * Class AbstractSlider
 * @package Mageplaza\StockStatus\Plugin\Block
 */
class AbstractSlider
{
    /**
     * @var Data
     */
    protected $helperData;

    /**
     * AbstractProduct constructor.
     *
     * @param Data $helperData
     */
    public function __construct(Data $helperData)
    {
        $this->helperData = $helperData;
    }

    /**
     * @param Productslider $abstractProduct
     * @param callable $proceed
     * @param Product $product
     *
     * @return string
     */
    public function aroundGetProductPriceHtml(Productslider $abstractProduct, callable $proceed, Product $product)
    {
        $status  = '';
        $product = $this->helperData->getProductData($product);
        if ($this->helperData->getStatus($product)
            && $this->helperData->isDisplayStatus($product->isAvailable(), PageType::PRODUCT_LIST)
        ) {
            $status = $this->helperData->getStatus($product);
        }

        return $proceed($product) . $status;
    }
}
