<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Plugin\Block\Cart\Item;

use Magento\Bundle\Block\Checkout\Cart\Item\Renderer;
use Mageplaza\StockStatus\Helper\Data;
use Mageplaza\StockStatus\Model\Config\Source\PageType;

/**
 * Class Bundle
 *
 * @package Mageplaza\StockStatus\Plugin\Block\Cart\Item
 */
class Bundle
{
    /**
     * @var Data
     */
    protected $helperData;

    /**
     * BundleOption constructor.
     *
     * @param Data $helperData
     */
    public function __construct(Data $helperData)
    {
        $this->helperData = $helperData;
    }

    /**
     * @param Renderer $subject
     */
    public function beforeToHtml(Renderer $subject)
    {
        if ($this->helperData->isEnabled()
            && in_array(PageType::SHOPPING_CART, $this->helperData->getDisplayPage(), true)
        ) {
            $subject->setTemplate('Mageplaza_StockStatus::cart/item/default.phtml');
        }
    }
}
