<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Test\Unit\Block\View\Type;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Block\Product\Context;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\Product\Type\AbstractType;
use Magento\Framework\Registry;
use Magento\Framework\Stdlib\ArrayUtils;
use Magento\Store\Api\Data\StoreInterface;
use Magento\Store\Model\StoreManagerInterface;
use Mageplaza\StockStatus\Block\Product\View\Type\Configurable;
use Mageplaza\StockStatus\Helper\Data;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class ConfigurableTest
 *
 * @package Mageplaza\StockStatus\Test\Unit
 */
class ConfigurableTest extends TestCase
{
    /**
     * @var Context|PHPUnit_Framework_MockObject_MockObject
     */
    protected $context;

    /**
     * @var ArrayUtils|PHPUnit_Framework_MockObject_MockObject
     */
    protected $arrayUtils;

    /**
     * @var ProductRepositoryInterface|PHPUnit_Framework_MockObject_MockObject
     */
    protected $productRepository;

    /**
     * @var Data|PHPUnit_Framework_MockObject_MockObject
     */
    protected $_helperData;

    /**
     * @var Registry|PHPUnit_Framework_MockObject_MockObject
     */
    protected $_coreRegistry;

    /**
     * Store manager
     *
     * @var StoreManagerInterface |PHPUnit_Framework_MockObject_MockObject
     */
    protected $_storeManager;

    /**
     * @var Configurable|PHPUnit_Framework_MockObject_MockObject
     */
    private $block;

    protected function setUp()
    {
        $this->context = $this->getMockBuilder(Context::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->arrayUtils = $this->getMockBuilder(ArrayUtils::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->productRepository = $this->getMockBuilder(ProductRepositoryInterface::class)
            ->getMock();

        $this->_helperData = $this->getMockBuilder(Data::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->_coreRegistry = $this->getMockBuilder(Registry::class)
            ->disableOriginalConstructor()
            ->getMock();
        $this->_storeManager = $this->getMockBuilder(StoreManagerInterface::class)->getMock();
        $this->context->method('getRegistry')->willReturn($this->_coreRegistry);
        $this->context->method('getStoreManager')->willReturn($this->_storeManager);

        $this->block = new Configurable(
            $this->context,
            $this->arrayUtils,
            $this->productRepository,
            $this->_helperData
        );
    }

    public function testAdminInstance()
    {
        static::assertInstanceOf(Configurable::class, $this->block);
    }

    public function testGetConfigurableChildren()
    {
        $data        = [
            '141' => [
                [
                    'sku'         => 'MH01-XS-Orange',
                    'product_id'  => '67',
                    'value_index' => '167'
                ]
            ]
        ];
        $status      = 'con hang';
        $resultArray = [
            'MH01-XS-Orange' => [
                '141'    => '167',
                'status' => $status
            ]
        ];
        $result      = '{MH01-XS-Orange:{93:"52",141:"167",status:"con hang"}}';
        $store       = $this->getMockBuilder(StoreInterface::class)
            ->disableOriginalConstructor()
            ->getMock();
        $this->_storeManager->method('getStore')->willReturn($store);
        $product = $this->getMockBuilder(Product::class)
            ->disableOriginalConstructor()
            ->getMock();

        $productAbstract = $this->getMockBuilder(AbstractType::class)
            ->disableOriginalConstructor()
            ->setMethods(['getConfigurableOptions', 'deleteTypeSpecificData'])
            ->getMock();

        $this->_coreRegistry->method('registry')->with('product')->willReturn($product);
        $product->method('getTypeInstance')->willReturn($productAbstract);
        $productAbstract->method('getConfigurableOptions')->with($product)->willReturn($data);
        $this->productRepository->method('get')->with($data['141']['0']['sku'])->willReturn($product);
        $this->_helperData->method('getStatus')->with($product)->willReturn($status);
        $this->_helperData->method('getJsonEncode')->with($resultArray)->willReturn($result);

        static::assertEquals($result, $this->block->getConfigurableChildren());
    }
}
