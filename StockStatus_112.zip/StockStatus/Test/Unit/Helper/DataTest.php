<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 23/02/2019
 * Time: 21:11 PM
 */

namespace Mageplaza\StockStatus\Test\Unit\Helper;

use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ProductFactory;
use Magento\CatalogInventory\Api\Data\StockItemInterface;
use Magento\CatalogInventory\Model\Stock\StockItemRepository;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\State;
use Magento\Framework\Escaper;
use Magento\Framework\ObjectManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Swatches\Helper\Data as SwatchData;
use Magento\Swatches\Helper\Media as SwatchMedia;
use Magento\Swatches\Model\Swatch;
use Mageplaza\StockStatus\Helper\Data;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class DataTest
 * @package Mageplaza\StockStatus\Test\Unit\Helper
 */
class DataTest extends TestCase
{
    /**
     * @var Context|PHPUnit_Framework_MockObject_MockObject
     */
    protected $context;

    /**
     * @var ObjectManagerInterface|PHPUnit_Framework_MockObject_MockObject
     */
    protected $objectManager;

    /**
     * @var StoreManagerInterface|PHPUnit_Framework_MockObject_MockObject
     */
    protected $storeManager;

    /**
     * @var SwatchData|PHPUnit_Framework_MockObject_MockObject
     */
    protected $swatchHelper;

    /**
     * @var SwatchMedia|PHPUnit_Framework_MockObject_MockObject
     */
    protected $swatchMediaHelper;

    /**
     * @var Escaper|PHPUnit_Framework_MockObject_MockObject
     */
    protected $_escaper;

    /**
     * @var StockItemRepository|PHPUnit_Framework_MockObject_MockObject
     */
    protected $_stockItemRepository;

    /**
     * @var ProductFactory|PHPUnit_Framework_MockObject_MockObject
     */
    protected $productFactory;

    /**
     * @var ScopeConfigInterface|PHPUnit_Framework_MockObject_MockObject
     */
    protected $scopeConfig;

    /**
     * @var Data|PHPUnit_Framework_MockObject_MockObject
     */
    private $helperData;

    protected function setUp()
    {
        $this->context              = $this->getMockBuilder(Context::class)
            ->disableOriginalConstructor()
            ->getMock();
        $this->objectManager        = $this->getMockBuilder(ObjectManagerInterface::class)
            ->getMock();
        $this->storeManager         = $this->getMockBuilder(StoreManagerInterface::class)
            ->getMock();
        $this->swatchHelper         = $this->getMockBuilder(SwatchData::class)
            ->disableOriginalConstructor()
            ->getMock();
        $this->swatchMediaHelper    = $this->getMockBuilder(SwatchMedia::class)
            ->disableOriginalConstructor()
            ->getMock();
        $this->_escaper             = $this->getMockBuilder(Escaper::class)
            ->disableOriginalConstructor()
            ->getMock();
        $this->_stockItemRepository = $this->getMockBuilder(StockItemRepository::class)
            ->disableOriginalConstructor()
            ->getMock();
        $this->productFactory       = $this->getMockBuilder(ProductFactory::class)
            ->disableOriginalConstructor()
            ->setMethods(['create'])
            ->getMock();

        $this->scopeConfig = $this->getMockBuilder(ScopeConfigInterface::class)->getMock();
        $this->context->method('getScopeConfig')->willReturn($this->scopeConfig);

        $this->helperData = new Data(
            $this->context,
            $this->objectManager,
            $this->storeManager,
            $this->swatchHelper,
            $this->swatchMediaHelper,
            $this->_escaper,
            $this->_stockItemRepository,
            $this->productFactory
        );
    }

    public function testAdminInstance()
    {
        static::assertInstanceOf(Data::class, $this->helperData);
    }

    public function testGetStatus()
    {
        $statusId     = '123';
        $swatchOption = [
            'option_id' => '1',
            'value'     => '/fff/aaa/ccc.jpg'
        ];
        $label        = 'in stock';
        $imageUrl     = 'https://localhost.com/image/swatch/fff/aaa/ccc.jpg';
        $qty          = '10';
        $result       = '<div class="stock available" title="' . $label . '"><p>' . $label . '</p></div>';

        $product = $this->getMockBuilder(Product::class)->disableOriginalConstructor()->getMock();
        $product->expects(static::at(0))->method('getData')->with('mp_stock_status')->willReturn($statusId);

        $this->swatchHelper->expects(static::at(0))
            ->method('getSwatchesByOptionsId')
            ->with([$statusId])
            ->willReturn($swatchOption);

        $this->swatchMediaHelper->method('getSwatchAttributeImage')
            ->with(Swatch::SWATCH_THUMBNAIL_NAME, $swatchOption['value'])
            ->willReturn($imageUrl);

        $product->method('getAttributeText')->with('mp_stock_status')->willReturn($label);
        $product->expects(static::at(2))->method('getData')->with('mp_dynamic_groups')->willReturn(null);
        $product->method('getTypeId')->willReturn('simple');
        $product->method('getId')->willReturn('1');
        $stockItemInterface = $this->getMockBuilder(StockItemInterface::class)
            ->getMock();
        $state              = $this->getMockBuilder(State::class)->disableOriginalConstructor()->getMock();
        $this->_stockItemRepository->method('get')->with('1')->willReturn($stockItemInterface);
        $stockItemInterface->method('getQty')->willReturn($qty);
        $this->objectManager->method('get')->with(State::class)->willReturn($state);
        $state->method('getAreaCode')->willReturn('frontend');
        $this->_escaper->method('escapeHtml')->with($label)->willReturn($label);

        static::assertEquals($result, $this->helperData->getStatus($product));
    }
}
