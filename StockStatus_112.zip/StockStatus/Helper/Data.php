<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Helper;

use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ProductFactory;
use Magento\Catalog\Model\ProductRepository;
use Magento\CatalogInventory\Model\Stock\StockItemRepository;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\ObjectManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Swatches\Helper\Data as SwatchData;
use Magento\Swatches\Helper\Media as SwatchMedia;
use Magento\Swatches\Model\Swatch;
use Mageplaza\Core\Helper\AbstractData;
use Mageplaza\StockStatus\Model\Config\Source\PageType;
use Mageplaza\StockStatus\Model\Config\Source\ProductType;
use Mageplaza\StockStatus\Model\Config\Source\StatusFormat;

/**
 * Class Data
 *
 * @package Mageplaza\StockStatus\Helper
 */
class Data extends AbstractData
{
    const CONFIG_MODULE_PATH = 'mpstockstatus';

    /**
     * @var SwatchData
     */
    protected $swatchHelper;

    /**
     * @var SwatchMedia
     */
    protected $swatchMediaHelper;

    /**
     * @var Escaper
     */
    protected $_escaper;

    /**
     * @var StockItemRepository
     */
    protected $_stockItemRepository;

    /**
     * @var ProductFactory
     */
    protected $productFactory;
    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * Data constructor.
     *
     * @param Context $context
     * @param ObjectManagerInterface $objectManager
     * @param StoreManagerInterface $storeManager
     * @param SwatchData $swatchHelper
     * @param SwatchMedia $swatchMedia
     * @param Escaper $escaper
     * @param StockItemRepository $stockItemRepository
     * @param ProductFactory $productFactory
     */
    public function __construct(
        Context $context,
        ObjectManagerInterface $objectManager,
        StoreManagerInterface $storeManager,
        SwatchData $swatchHelper,
        SwatchMedia $swatchMedia,
        Escaper $escaper,
        StockItemRepository $stockItemRepository,
        ProductFactory $productFactory,
        ProductRepository $productRepository
    ) {
        $this->swatchHelper         = $swatchHelper;
        $this->swatchMediaHelper    = $swatchMedia;
        $this->_escaper             = $escaper;
        $this->_stockItemRepository = $stockItemRepository;
        $this->productFactory       = $productFactory;

        parent::__construct($context, $objectManager, $storeManager);
        $this->productRepository = $productRepository;
    }

    /**
     * @param null $store
     *
     * @return mixed
     */
    public function getProductType($store = null)
    {
        return $this->getConfigGeneral('product_type', $store);
    }

    /**
     * @param mixed $type
     *
     * @return bool
     */
    public function checkProductType($type)
    {
        return ($this->getProductType() == $type || $this->getProductType() === ProductType::BOTH);
    }

    /**
     * @param null $store
     *
     * @return mixed
     */
    public function getStatusFormat($store = null)
    {
        return $this->getConfigGeneral('status_format', $store);
    }

    /**
     * @param null $store
     *
     * @return array|mixed
     */
    public function getDisplayPage($store = null)
    {
        $page = $this->getConfigGeneral('display_page', $store);
        if (!is_array($page)) {
            $page = explode(',', $page);
        }

        return $page;
    }

    /**
     * @param null $store
     *
     * @return mixed
     */
    public function isDisplayChildProduct($store = null)
    {
        return $this->getConfigGeneral('display_child_product', $store);
    }

    /**
     * @param null $store
     *
     * @return mixed
     */
    public function isEnabledDynamicGroup($store = null)
    {
        return $this->getConfigGeneral('enabled_dynamic_group', $store);
    }

    /**
     * @param mixed $productType
     * @param string $pageType
     * @param null $store
     *
     * @return bool
     */
    public function isDisplayStatus($productType, $pageType, $store = null)
    {
        return $this->isEnabled($store)
            && $this->checkProductType($productType)
            && in_array($pageType, $this->getDisplayPage(), true);
    }

    /**
     * @param Product $product
     *
     * @return bool|mixed
     */
    public function checkUseDynamicGroup(Product $product)
    {
        if ($product->getData('mp_dynamic_groups') && $this->isEnabledDynamicGroup()) {
            return $product->getData('mp_dynamic_groups');
        }

        return false;
    }

    /**
     * Check the current page is OSC
     *
     * @param null $store
     *
     * @return bool
     */
    public function isOscPage($store = null)
    {
        $moduleEnable = $this->isEnabled($store);
        $isOscModule  = ($this->_request->getRouteName() === 'onestepcheckout');

        return $moduleEnable && $isOscModule && in_array(PageType::MAGEPLAZA_OSC, $this->getDisplayPage(), true);
    }

    /**
     * @param array $optionIds
     *
     * @return array
     */
    public function getSwatchesByOptionsId(array $optionIds)
    {
        return $this->swatchHelper->getSwatchesByOptionsId($optionIds);
    }

    /**
     * @param string $path
     *
     * @return string
     */
    public function getSwatchImageUrl($path)
    {
        return $this->swatchMediaHelper->getSwatchAttributeImage(Swatch::SWATCH_THUMBNAIL_NAME, $path);
    }

    /**
     * @param Product $product
     *
     * @return string
     */
    public function getStatusImage(Product $product)
    {
        $urlImage   = '';
        $optionId[] = $product->getData('mp_stock_status');
        if (!empty($optionId)) {
            $swatchData = $this->getSwatchesByOptionsId($optionId);
            foreach ($swatchData as $value) {
                if (isset($value['value']) && strpos($value['value'], '#') !== 0 && strlen($value['value']) > 7) {
                    $urlImage = $this->getSwatchImageUrl($value['value']);
                }
            }
        }

        return $urlImage;
    }

    /**
     * @param string $label
     * @param string $imageUrl
     *
     * @return string
     */
    public function processStatus($label, $imageUrl)
    {
        $status    = '';
        $labelHtml = '<p>' . $this->_escaper->escapeHtml($label) . '</p>';
        $image     = ($imageUrl !== '') ? '<img src="' . $imageUrl . '" alt="' . $label . '" >' : '';
        $format    = $this->getStatusFormat();
        switch ($format) {
            case StatusFormat::ONLY_LABEL:
                $status = $labelHtml;
                break;
            case StatusFormat::ONLY_IMAGE:
                $status = $image;
                break;
            case StatusFormat::LABEL_IMAGE:
                $status = $labelHtml . $image;
                break;
            case StatusFormat::IMAGE_LABEL:
                $status = $image . $labelHtml;
                break;
        }

        $status = '<div class="stock available" title="' . $label . '">' . $status . '</div>';

        return $status;
    }

    /**
     * @param Product $product
     * @param bool $isHtml
     *
     * @return string|array
     */
    public function getStatus(Product $product, $isHtml = true)
    {
        $status       = '';
        $imageUrl     = $this->getStatusImage($product);
        $label        = $product->getAttributeText('mp_stock_status');
        $dynamicGroup = $this->checkUseDynamicGroup($product);
        $productQty   = ($product->getTypeId() === 'simple')
            ? $this->getProductQty($product)
            : $this->getMaxQtyConfigurableChildren($product);

        if ($dynamicGroup) {
            $dataGroup    = $this->unserialize(
                $product->getResource()
                    ->getAttribute('mp_dynamic_groups')
                    ->getData('additional_data')
            );
            $dynamicGroup = explode(',', $dynamicGroup);

            foreach ($dataGroup as $key => $value) {
                if (isset($value['group_name'])
                    && $productQty >= $value['qty_from']
                    && $productQty <= $value['qty_to']
                    && in_array($value['group_name'], $dynamicGroup, true)
                ) {
                    $optionId   = $value['stock_status'];
                    $swatchData = $this->getSwatchesByOptionsId([$optionId]);

                    if (!empty($swatchData)) {
                        $statusData = array_values($swatchData)[0];
                        if (isset($statusData['value'])) {
                            $imageUrl = $this->getSwatchImageUrl($statusData['value']);
                        }
                    }
                    $label = $product->getResource()
                        ->getAttribute('mp_stock_status')
                        ->getSource()
                        ->getOptionText($optionId);
                    break;
                }
            }
        }
        $label = str_replace(['{{qty}}', '{{attribute_code}}'], [$productQty, 'mp_stock_status'], $label);

        if (!$isHtml) {
            return [
                'image' => $imageUrl,
                'label' => $label
            ];
        }

        if ($label || $imageUrl) {
            $status = $this->processStatus($label, $imageUrl);
        }

        return $status;
    }

    /**
     * @param $product
     *
     * @return float
     */
    public function getProductQty($product)
    {
        try {
            return $this->_stockItemRepository->get($product->getId())->getQty();
        } catch (NoSuchEntityException $e) {
            $stock = $product->getData('quantity_and_stock_status');

            return isset($stock['qty']) ? $stock['qty'] : 0;
        }
    }

    /**
     * @param Product $product
     *
     * @return int|mixed
     */
    public function getMaxQtyConfigurableChildren(Product $product)
    {
        $stockQty    = $this->getProductQty($product);
        $childrenIds = $product->getTypeInstance()->getChildrenIds($product->getId());
        if (!empty($childrenIds)) {
            foreach ($childrenIds as $children) {
                foreach ($children as $childId) {
                    try {
                        $childQty = $this->_stockItemRepository->get($childId)->getQty();
                    } catch (NoSuchEntityException $e) {
                        $childQty = 0;
                    }
                    $stockQty = max($stockQty, $childQty);
                }
            }
        }

        return $stockQty;
    }

    /**
     * @param Product $product
     *
     * @return Product
     */
    public function getProductData(Product $product)
    {
        $productId = $product->getId();

        return $this->productFactory->create()->load($productId);
    }

    /**
     * @param $sku
     *
     * @return Product
     */
    public function getProductBySku($sku)
    {
        return $this->productRepository->get($sku);
    }

    /**
     * @param mixed $data
     *
     * @return string
     */
    public function getJsonEncode($data)
    {
        return self::jsonEncode($data);
    }
}
