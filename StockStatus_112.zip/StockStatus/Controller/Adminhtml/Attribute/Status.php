<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Controller\Adminhtml\Attribute;

use Exception;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Catalog\Model\Product\Attribute\Repository;
use Magento\Eav\Api\Data\AttributeInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Mageplaza\StockStatus\Helper\Data;

/**
 * Class View
 *
 * @package Mageplaza\StockStatus\Controller\Adminhtml\Attribute\Status
 */
class Status extends Action
{
    /**
     * @type Data
     */
    protected $_helperData;

    /**
     * @type Repository
     */
    protected $_attributeRepository;

    /**
     * View constructor.
     *
     * @param Context $context
     * @param Repository $repository
     * @param Data $helperData
     */
    public function __construct(
        Context $context,
        Repository $repository,
        Data $helperData
    ) {
        $this->_attributeRepository = $repository;
        $this->_helperData          = $helperData;

        parent::__construct($context);
    }

    /**
     * @return ResponseInterface|ResultInterface|void
     */
    public function execute()
    {
        try {
            /** @var AttributeInterface $attribute */
            $attribute = $this->_attributeRepository->get('mp_stock_status');

            $this->_forward('edit', 'product_attribute', 'catalog', ['attribute_id' => $attribute->getAttributeId()]);
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }
    }
}
