<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Model\Config\Source;

use Magento\Framework\Module\Manager;
use Magento\Framework\Option\ArrayInterface;

/**
 * Class PageType
 *
 * @package Mageplaza\StockStatus\Model\Config\Source
 */
class PageType implements ArrayInterface
{
    const PRODUCT_VIEW  = '0';
    const PRODUCT_LIST  = '1';
    const SHOPPING_CART = '3';
    const MAGEPLAZA_OSC = '4';
    const SALE_EMAIL = '5';

    /**
     * @var Manager
     */
    protected $moduleManager;

    /**
     * EnableFAQ constructor.
     *
     * @param Manager $moduleManager
     */
    public function __construct(Manager $moduleManager)
    {
        $this->moduleManager = $moduleManager;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $option = [
            ['value' => self::PRODUCT_VIEW, 'label' => __('Product View Page')],
            ['value' => self::PRODUCT_LIST, 'label' => __('Product Listing Page')],
            ['value' => self::SHOPPING_CART, 'label' => __('Shopping Cart Page')],
            ['value' => self::SALE_EMAIL, 'label' => __('Sales Email')]
        ];

        if ($this->moduleManager->isOutputEnabled('Mageplaza_Osc')) {
            $option[] = [
                'value' => self::MAGEPLAZA_OSC,
                'label' => __('Mageplaza One Step Checkout Page')
            ];
        }

        return $option;
    }
}
