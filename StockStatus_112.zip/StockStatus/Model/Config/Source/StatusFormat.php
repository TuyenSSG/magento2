<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class StatusFormat
 *
 * @package Mageplaza\StockStatus\Model\Config\Source
 */
class StatusFormat implements ArrayInterface
{
    const ONLY_LABEL  = 0;
    const ONLY_IMAGE  = 1;
    const LABEL_IMAGE = 2;
    const IMAGE_LABEL = 3;

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => self::ONLY_LABEL, 'label' => __('Text Only')],
            ['value' => self::ONLY_IMAGE, 'label' => __('Image Only')],
            ['value' => self::LABEL_IMAGE, 'label' => __('Text & Image')],
            ['value' => self::IMAGE_LABEL, 'label' => __('Image & Text')]
        ];
    }
}
