<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_StockStatus
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\StockStatus\Model\Config\Source;

use Magento\CatalogInventory\Model\Stock;
use Magento\Framework\Option\ArrayInterface;

/**
 * Class ProductType
 *
 * @package Mageplaza\StockStatus\Model\Config\Source
 */
class ProductType implements ArrayInterface
{
    const BOTH = '2';

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => Stock::STOCK_IN_STOCK, 'label' => __('In Stock')],
            ['value' => Stock::STOCK_OUT_OF_STOCK, 'label' => __('Out of Stock')],
            ['value' => self::BOTH, 'label' => __('Both')],
        ];
    }
}
