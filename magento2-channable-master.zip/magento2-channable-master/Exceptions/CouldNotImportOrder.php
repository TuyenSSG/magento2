<?php
/**
 * Copyright © Magmodules.eu. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magmodules\Channable\Exceptions;

use Magento\Framework\Exception\LocalizedException;

class CouldNotImportOrder extends LocalizedException
{

}